package co.edu.unbosque.view;

public class Vista {

}
