package co.edu.unbosque.controller;

import co.edu.unbosque.view.VentanaPrincipal;

public class Controller {
	public Controller()
	{
		VentanaPrincipal vp = new VentanaPrincipal(this);
	}
}
